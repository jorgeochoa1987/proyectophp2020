<?php
require('../../conex/conexion.php');
if ($_POST['atributo']=='crear')
{
  $name = $_POST['feFirstName'];
  $ced = $_POST['feCed'];  
  $plataforma = $_POST['fePlataforma'];
  $pista = $_POST['fePista'];  
  $carga =  $_POST['fePista'];  
  $caballo = $_POST['feCaballo'];
  $tipo = 'participante'; 
  $monto = $_POST['feMonto']; 
  $cod =$_POST['feCaballo'].rand(1,99);
  if($name=='' or $ced =='')
  {
    echo '<div class="comment_box" id="Respuesta"> Es Obligatorio llenar la contraseña y usuario </div>';
    exit();
  } 
  $sql = "INSERT INTO `apuesta` (`id`, `fecha_apuesta`, `plataforma`, `pista`, `caballo`, `tipo`, `carga`, `monto`,`cod`, `nombreapellido`, `cedula`) VALUES
                                (NULL, current_timestamp(), '$plataforma', '$pista',' $caballo', '$tipo','$carga', '$monto ', '$cod', '$name', '$ced');";
  if (mysqli_query($conexion, $sql)) {
  
      header('Location: ../../aplication/listarapuesta.php');
  }else {
    echo "Error: ". mysqli_error($conexion);
  }
  exit();

}
else if ($_GET['atributo']=='borrar')
{
  $id = $_GET['id']; 
   
  $sql = "DELETE FROM `apuesta` WHERE `id` = $id";
  if (mysqli_query($conexion, $sql)) {
  
      header('Location: ../../aplication/listarapuesta.php');
  }else {
    echo "Error: ". mysqli_error($conexion);
  }
  exit();
}
if ($_POST['atributo']=='actualizar')
{
  $id=$_POST['id_apuesta'];
  $name = $_POST['feFirstName'];
  $ced = $_POST['feCed'];  
  $plataforma = $_POST['fePlataforma'];
  $pista = $_POST['fePista'];  
  $carga =  $_POST['fePista'];  
  $caballo = $_POST['feCaballo'];
  $tipo =  $_POST['feTipo']; 
  $monto = $_POST['feMonto']; 
  $cod =$_POST['feCaballo'].rand(1,99);
  if($name=='' or $ced =='')
  {
    echo '<div class="comment_box" id="Respuesta"> Es Obligatorio llenar la contraseña y usuario </div>';
    exit();
  } 
  $sql = "UPDATE `apuesta` SET `plataforma` = '$plataforma', `pista` = '$pista', `caballo` = ' $caballo', `tipo` = '$tipo', `carga` = '$carga', `monto` = '$monto', `cod` = '$cod', `nombreapellido` = '$name', `cedula` = '$ced' WHERE `apuesta`.`id` = $id;";
  if (mysqli_query($conexion, $sql)) {
  
      header('Location: ../../aplication/listarapuesta.php');
  }else {
    echo "Error: ". mysqli_error($conexion);
  }
  exit();
}

   
  
  ?>